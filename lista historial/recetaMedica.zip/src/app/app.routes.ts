import { Routes } from '@angular/router';

export const routes: Routes = [
  { path:'crear-pacientes', loadComponent: () => import('./pages/pacientes/crear-paciente/crear-paciente.component').then(m => m.CrearPacienteComponent) },
  { path:'lista-pacientes', loadComponent: () => import('./pages/pacientes/lista-paciente/lista-paciente.component').then(m => m.ListaPacienteComponent) },
  { path:'crear-historial', loadComponent: () => import('./pages/historial/crear-historial/crear-historial.component').then(m => m.CrearHistorialComponent) },
  { path:'lista-historial', loadComponent: () => import('./pages/historial/lista-historial/lista-historial.component').then(m => m.ListaHistorialComponent) },
  { path: '', redirectTo: '/crear-pacientes', pathMatch: 'full' },
];