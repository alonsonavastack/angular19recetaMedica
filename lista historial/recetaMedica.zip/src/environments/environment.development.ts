export const environment = {
  url: 'http://localhost/gineco/api/',
  production: true
};
